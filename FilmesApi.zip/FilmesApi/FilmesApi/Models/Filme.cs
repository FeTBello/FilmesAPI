﻿using System.ComponentModel.DataAnnotations;

namespace FilmesApi.Models;

public class Filme
{
    [Key]
    [Required]
    public int Id { get; set; }
    [Required(ErrorMessage= "Campo obrigatorio")]
    public string Titulo { get; set; }
    
    [Required]
    [Range(70, 600, ErrorMessage = "Duração invalida")]
    public int Duracao { get; set; }

    [Required(ErrorMessage = "Campo obrigatorio")]
    [MaxLength(50, ErrorMessage = "O tamanho do filme não aceito")]
    public string Genero { get; set; }
    public virtual ICollection<Sessao> Sessoes { get; set; }
}

