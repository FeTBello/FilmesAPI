﻿using AutoMapper;
using FilmesApi.Data;
using FilmesApi.Data.DTOS;
using FilmesApi.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FilmesApi.Controllers;

[ApiController]
[Route("[controller]")]
public class FilmeController : ControllerBase
{
    private static List<Filme> filmes = new List<Filme>();
    private static int id = 0;

    private FilmeContext _context;

    public FilmeController (FilmeContext context)
    {
        _context = context;
    }

    private IMapper _mapper;

    public FilmeController(IMapper mapper)
    {
        _mapper = mapper;
    }
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]



    [HttpGet]
    public IEnumerable<ReadFilmeDto> RecuperaFilmes([FromQuery] int skip = 0,
    [FromQuery] int take = 5,
    [FromQuery] string? nomeCinema = null)
    { if(nomeCinema == null) 
        {
            return _mapper.Map<List<ReadFilmeDto>>(_context.Filmes.Skip(skip).Take(take).ToList());
        }
        return _mapper.Map<List<ReadFilmeDto>>(_context.Filmes.Skip(skip).Take(take).Where(filme => filme.Sessoes.Any(sessao => sessao.Cinema.Nome == nomeCinema)).ToList());
    }
    



    [HttpPost]
    public IActionResult AdicionarFilme([FromBody] CreatedFilmeDto filmeDto)
    {
        Filme filme = _mapper.Map<Filme>(filmeDto);
        filme.Id = id ++;
        filmes.Add(filme);
        return CreatedAtAction(nameof(RecuperarFilmePorId), new {id = filme.Id}, filme);
    }

    [HttpGet]
    public IEnumerable<ReadFilmeDto> LerFilmes([FromQuery] int skip = 0, [FromQuery] int take = 50)
    {
        return _mapper.Map<List<ReadFilmeDto>>(_context.Filmes.Skip(skip).Take(take));
    }
    [HttpGet("{id}")]
    public IActionResult RecuperarFilmePorId(int id)
    {
       var filme = filmes.FirstOrDefault(filme => filme.Id == id);
        if (filme == null) return NotFound();
        var filmedto = _mapper.Map<ReadFilmeDto>(filme);   
        return Ok(filmedto);
    }

    //[HttpPut("{id}")]
    //public IActionResult AtualizarFilme(int id, JsonPatchDocument<Updatefilmedto> patch)
    //{
    //    var filme = _context.Filmes.First0rDefault(filme = filme.Id == id);

    //    if (filme == null) return NotFound();
    //    var filmeparaatualizar = _mapper.Map<Updatedilmedto>(filme));
    //    patch.Applyto(filmeparaatualizar, ModelState);
    //    if (!TryValidateModel(filmeparaatualizar))
    //        return VlidationProblem(ModelState)
    //      _mapper.Map(filmeparaatualizar, filme);
    //    _context.SaveChanges();
    //    return NoContent();

    //}

    [HttpDelete]
    public IActionResult Delete(int id) 
    {
        var filme = _context.Filmes.FirstOrDefault(filme => filme.Id == id);
         if (filme == null) return NotFound();
        _context.Remove(filme);
        _context.SaveChanges();
        return NoContent();
    }
}

