﻿using System.ComponentModel.DataAnnotations;

namespace FilmesApi.Data.DTOS
{
    public class CreateCinemaDto
    {
        [Required(ErrorMessage = "Campo Obrigatorio")]    
        public string Nome { get; set; }

        public int EnderecoId { get; set; }
    }
}
