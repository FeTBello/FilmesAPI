﻿using System.ComponentModel.DataAnnotations;

namespace FilmesApi.Data.DTOS
{
    public class ReadEnderecoDto
    {
        public int Id { get; set; }
        public string Logadouro { get; set; }
        public int Numero { get; set; }
    }
}
