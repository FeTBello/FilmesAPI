﻿namespace FilmesApi.Data.DTOS
{
    public class UpdateCinemaDto
    { 
        public string Nome { get; set; }
    }
}
