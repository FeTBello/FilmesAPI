﻿using System.ComponentModel.DataAnnotations;

namespace FilmesApi.Data.DTOS
{
    public class CreateEnderecoDto
    {
        public string Logadouro { get; set; }
        public int Numero { get; set; }
    }
}
