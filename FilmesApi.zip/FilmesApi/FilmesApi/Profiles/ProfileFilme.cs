﻿using AutoMapper;
using FilmesApi.Data.DTOS;
using FilmesApi.Models;

namespace FilmesApi.Profiles;

public class ProfileFilme : Profile
{
    public ProfileFilme()
    {
        CreateMap<CreatedFilmeDto, Filme>();
        CreateMap< Filme, ReadFilmeDto>().ForMember(filmeDto => filmeDto.Sessoes, opt => opt.MapFrom(filme => filme.Sessoes)); ;
        CreateMap<UpdateFilmeDto, Filme>();
        
    }
}
            
            
